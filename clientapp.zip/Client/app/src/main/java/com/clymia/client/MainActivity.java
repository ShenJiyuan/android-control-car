package com.clymia.client;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.net.nsd.NsdServiceInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.PowerManager;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class MainActivity extends Activity implements View.OnClickListener, Camera.PictureCallback, ControlFragment.OnButtonClickedListener_Control{
    Activity mAct = this;
    NsdHelper mNsdHelper = null;
    ChatConnection mConnection;

    private boolean RegisterSuccess;
    private boolean ConnectSuccess;
    private PowerManager pm;
    private PowerManager.WakeLock mWakeLock;

    private Handler mUpdateHandler;

    private FragmentManager fragmentManager;
    private ControlFragment controlFragment;

    private Button mCaptureButton = null;
    private CameraSurfacePreview mCameraPreview = null;

    private String TAG = "Picture capturing…";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        RegisterSuccess = false;
        ConnectSuccess =false;

        //初始化NSD
        initNSD();


        // 初始化布局元素
        initViews();
        fragmentManager = getFragmentManager();

        pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "My Tag");
        // in onResume() call

        mWakeLock.acquire();

//        setTabSelection(1);
    }


    /**
     * 初始化NSD
     */
    private void initNSD(){
        mUpdateHandler = new Handler();
        mConnection = new ChatConnection(mUpdateHandler, mAct);
        mNsdHelper = new NsdHelper(this);
        mNsdHelper.initializeNsd();
    }

    private void initCameraPreview(){
        FrameLayout preview = (FrameLayout) findViewById(R.id.camera_preview);
        mCameraPreview = new CameraSurfacePreview(this);
        preview.addView(mCameraPreview);
    }

    /**
     * 在这里获取到每个需要用到的控件的实例，并给它们设置好必要的点击事件。
     */
    private void initViews() {
        /**
         * 控制按钮、册按钮、连接按钮、拍照按钮
         */
        Button controlButton = (Button) findViewById(R.id.button_control);
        Button registerButton = (Button) findViewById(R.id.button_register);
        Button connectButton = (Button) findViewById(R.id.button_connect);
        mCaptureButton = (Button) findViewById(R.id.button_capture);

        /**
         * 设置控制、注册、连接、拍照的监听
         */
        controlButton.setOnClickListener(this);

        registerButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (!RegisterSuccess){
                    if (mConnection.getLocalPort() > -1) {
                        mNsdHelper.registerService(mConnection.getLocalPort());
                        showToast("注册成功" + mConnection.getLocalPort());
                        RegisterSuccess = true;
                    }
                }

            }
        });


        connectButton.setOnClickListener(new OnClickListener(){
            public void onClick(View v) {
                if (!ConnectSuccess){
                    mNsdHelper.discoverServices();
                    //service是discover到的一个
                    NsdServiceInfo service = mNsdHelper.getChosenServiceInfo();
                    if (service != null) {
                        mConnection.connectToServer(service.getHost(),
                                service.getPort());
                        showToast("连接" + service.getPort());
                        ConnectSuccess = true;
                        initCameraPreview();
                    }
                }
            }});
        mCaptureButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.button_control:
                // 当点击了控制按钮时，选中第2个tab
                setTabSelection(1);
                break;
            case R.id.button_capture:
                mCaptureButton.setEnabled(false);
                mCameraPreview.takePicture(this);
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        mNsdHelper.tearDown();
        mConnection.tearDown();
        super.onDestroy();
    }

    /**
     * 根据传入的index参数来设置选中的tab页。
     *
     * @param index
     *            每个tab页对应的下标。0表示消息，1表示联系人，2表示动态，3表示设置。
     */
    private void setTabSelection(int index) {
        // 每次选中之前先清楚掉上次的选中状态
        // 开启一个Fragment事务
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        // 先隐藏掉所有的Fragment，以防止有多个Fragment显示在界面上的情况
        hideFragments(transaction);
        switch (index) {

            case 1:
                if (controlFragment == null) {
                    // 如果ControlFragment为空，则创建一个并添加到界面上
                    controlFragment = new ControlFragment();
                    transaction.add(R.id.content, controlFragment);
                } else {
                    // 如果ControlFragment不为空，则直接将它显示出来
                    transaction.show(controlFragment);
                }
                break;

            default:
                break;
        }
        transaction.commit();
    }

    /**
     * 将所有的Fragment都置为隐藏状态。
     * 用于对Fragment执行操作的事务
     */
    private void hideFragments(FragmentTransaction transaction) {
        if (controlFragment != null) {
            transaction.hide(controlFragment);
        }

    }


    /**
     * 与Control界面的接口
     */
    public void onButtonClicked_control(String ButtonText){
        mConnection.sendMessage(ButtonText);
    }

    @Override
    public void onPictureTaken(byte[] data, Camera camera) {

        File pictureFile = getOutputMediaFile();
        if (pictureFile == null){
            Log.d(TAG, "Error creating media file!");
            return;
        }

        try {
            FileOutputStream fos = new FileOutputStream(pictureFile);
            fos.write(data);
            fos.close();

            Toast.makeText(this, "Image has been saved to " + pictureFile.getAbsolutePath(),
                    Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException e) {
            Log.d(TAG, "File not found: " + e.getMessage());
        } catch (IOException e) {
            Log.d(TAG, "Error accessing file: " + e.getMessage());
        }
        camera.startPreview();
        mCaptureButton.setEnabled(true);
    }

    private File getOutputMediaFile(){
        //get the mobile Pictures directory
        File picDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);

        //get the current time
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());

        return new File(picDir.getPath() + File.separator + "IMAGE_"+ timeStamp + ".jpg");
    }

    public void showToast(final String text){
        mAct.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast toast = Toast.makeText(mAct, text, Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();

            }
        });
    }

}
