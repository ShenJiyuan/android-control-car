package com.clymia.client;

/**
 * Created by hcccccc on 2015/6/14.
 */
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class CameraSurfacePreview extends SurfaceView implements SurfaceHolder.Callback {
    private SurfaceHolder mHolder;
    private Canvas canvas;
    private Matrix matrix = new Matrix();


    public CameraSurfacePreview(Context context) {
        super(context);

        // Install a SurfaceHolder.Callback so we get notified when the
        // underlying surface is created and destroyed.
        mHolder = getHolder();
        mHolder.addCallback(this);
        // deprecated setting, but required on Android versions prior to 3.0
        mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
    }

    public void surfaceCreated(SurfaceHolder holder) {

        Thread th = new MyThread();
        th.start();
        th.setPriority(Thread.NORM_PRIORITY + 5);
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {

    }

    public void surfaceDestroyed(SurfaceHolder holder) {

    }

    public void takePicture(PictureCallback imageCallback) {
        //mCamera.takePicture(null, null, imageCallback);
    }

    class MyThread extends Thread {
        public Socket s;
        public ServerSocket ss;

        public void run() {
            byte[] buffer = new byte[1024];
            int len = 0;
            try {
                ss = new ServerSocket(6000);
            } catch (IOException e2) {
// TODO Auto-generated catch block
                e2.printStackTrace();
            }
            while (true) {
                ByteArrayOutputStream outStream = new ByteArrayOutputStream();
                InputStream ins = null;
                try {
                    s = ss.accept();
                    ins = s.getInputStream();
                } catch (IOException e) {
// TODO Auto-generated catch block
                    e.printStackTrace();
                }
//Bitmap bitmap = BitmapFactory.decodeStream(ins);
                try {
                    while ((len = ins.read(buffer)) != -1) {
                        outStream.write(buffer, 0, len);
                    }
                } catch (IOException e1) {
// TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    outStream.flush();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                byte data[] = outStream.toByteArray();
                Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                matrix.setRotate(90,bitmap.getWidth()/2,bitmap.getHeight()/2);
                matrix.postTranslate(-bitmap.getWidth()/13,0);
                matrix.postScale(2, 2);

                canvas = mHolder.lockCanvas(); // 通过lockCanvas加锁并得到該SurfaceView的画布
                canvas.drawColor(Color.BLACK);
                canvas.drawBitmap(bitmap, matrix, null); // 把SurfaceView的画布传给物件，物件会用这个画布将自己绘制到上面的某个位置
                mHolder.unlockCanvasAndPost(canvas); // 释放锁并提交画布进行重绘
                if(!bitmap.isRecycled())
                    bitmap.recycle();
                System.gc();

                //handler.sendMessage(msg);
                try {
                    ins.close();
                    outStream.close();
                } catch (IOException e) {
// TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
    }
}
