package com.clymia.client;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

public class ControlFragment extends Fragment {

    private String msg;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View controlLayout = inflater.inflate(R.layout.control_layout,
                container, false);

        final ImageButton control_button_down = (ImageButton) controlLayout.findViewById(R.id.button2);
        final ImageButton control_button_up = (ImageButton) controlLayout.findViewById(R.id.button1);
        final ImageButton control_button_left = (ImageButton) controlLayout.findViewById(R.id.button3);
        final ImageButton control_button_right = (ImageButton) controlLayout.findViewById(R.id.button4);
        final ImageButton control_button_stop = (ImageButton) controlLayout.findViewById(R.id.button5);
        final Button control_button_speed1 = (Button) controlLayout.findViewById(R.id.speedButton1);
        final Button control_button_speed2 = (Button) controlLayout.findViewById(R.id.speedButton2);
        final Button control_button_speed3 = (Button) controlLayout.findViewById(R.id.speedButton3);
        final Button control_button_speed4 = (Button) controlLayout.findViewById(R.id.speedButton4);

        control_button_down.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                msg = "2";
                onButtonClickedListener_control.onButtonClicked_control(msg);
            }});

        control_button_up.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                msg = "1";
                onButtonClickedListener_control.onButtonClicked_control(msg);
            }});

        control_button_left.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                msg = "3";
                onButtonClickedListener_control.onButtonClicked_control(msg);
            }});

        control_button_right.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                msg = "4";
                onButtonClickedListener_control.onButtonClicked_control(msg);
            }});
        control_button_speed1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                msg = "5";
                onButtonClickedListener_control.onButtonClicked_control(msg);
            }});
        control_button_speed2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                msg = "6";
                onButtonClickedListener_control.onButtonClicked_control(msg);
            }});
        control_button_speed3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                msg = "7";
                onButtonClickedListener_control.onButtonClicked_control(msg);
            }});
        control_button_speed4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                msg = "8";
                onButtonClickedListener_control.onButtonClicked_control(msg);
            }});
        control_button_stop.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                msg = "0";
                onButtonClickedListener_control.onButtonClicked_control(msg);
            }});

        return controlLayout;
    }

    //onButtonClicked_control在MainActivity中实现
    public interface OnButtonClickedListener_Control {
        public void onButtonClicked_control(String ButtonText);
    }

    private OnButtonClickedListener_Control onButtonClickedListener_control;

    @Override
    public void onAttach(Activity activity){
        super.onAttach(activity);

        try {
            onButtonClickedListener_control = (OnButtonClickedListener_Control) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + "must implement OnButtonClickedListener");
        }
    }



}
